function init() {
// initialization code

}

function destroy() {
// view hide code

}

function periodic() {
// periodically triggering code
  
}

